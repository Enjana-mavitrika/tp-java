package dessin;

public class Triangle extends Polygone
{
    // constructors
    public Triangle(Point p1, Point p2, Point p3)
    {
	super(3);
	super.changePoint(1, p1);
	super.changePoint(2, p2);
	super.changePoint(3, p3);
    }

    // methods
    public void changeSommet(int n, double x, double y)
    {
	super.changePoint(n, x, y);
    }

    
    // public String toString()
    // {
    // 	int i;
    // 	String str = new String();
    // 	str = "Triangle: ";
    // 	for (i = 1; i <= super.nbrCotes(); i++)
    // 	    {
    // 		str += super.getPoint(i) + " ";
    // 	    }

    // 	return str;
    // }
}
